﻿using UnityEngine;
using System.Collections;

public class AsteroidController : MonoBehaviour
{
    public GameObject smallAsteroid;

    private GameController gameController;

    //initialize
    void Start()
    {
        // setting up game controller
        GameObject gameController = GameObject.FindWithTag("GameController");

        this.gameController = gameController.GetComponent<GameController>();

        // send asteroid in direction it's facing
        GetComponent<Rigidbody2D>()
            .AddForce(transform.up * Random.Range(-45.0f, 170.0f));

        // gives a random rotation
        GetComponent<Rigidbody2D>().angularVelocity = Random.Range(0.0f, 80.0f);

    }

    void SpawnSmallAsteroid()
    {
        Instantiate(smallAsteroid,new Vector3(transform.position.x - 0.5f,transform.position.y - 0.7f, 0),
                Quaternion.Euler(0, 0, 90));
    }

    void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.tag.Equals("Bullet"))
        {

            // destroy bullet on collision
            Destroy(collision.gameObject);

            // if large asteroid destroyed, spawn 3 new small ones
            if (tag.Equals("Large Asteroid"))
            {
                //instantiate small asteroids
                SpawnSmallAsteroid();
                SpawnSmallAsteroid(); 
                SpawnSmallAsteroid();

                gameController.SplitAsteroid(); // +2 asteroids on split

            }
            else
            {
                // destroy a small asteroid
                gameController.DecrementAsteroids();
            }
            // increment the score
            gameController.IncrementScore();
            //destroy current asteroid
            Destroy(gameObject);
        }

    }
}