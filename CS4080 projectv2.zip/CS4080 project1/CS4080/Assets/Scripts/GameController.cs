﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{

    public GameObject asteroid;

    private int highscore;
    private int score;
    private int asteroidsLeft;
    private int morePerWave = 2;
    private int lives;
    private int wave;

    public Text scoreText;
    public Text highscoreText;
    public Text livesText;
    public Text waveText;
 

    //initialize
    void Start()
    {

        highscore = PlayerPrefs.GetInt("hiscore", 0);
        BeginGame();
    }

    //update every frame
    void Update()
    {
        // hit escape to quit
        if (Input.GetKey("escape"))Application.Quit();
    }

    void BeginGame()
    {

        score = 0;
        lives = 4;
        wave = 1;

        // Set up GUI text
        scoreText.text = "Score: " + score;
        highscoreText.text = "High Score: " + highscore;
        livesText.text = "Lives: " + lives;
        waveText.text = "Wave: " + wave;

        SpawnAsteroids();
    }

    void UpdateText()
    {
        // refresh text
        scoreText.text = "Score: " + score;
        highscoreText.text = "High Score: " + highscore;
        livesText.text = "Lives: " + lives;
        waveText.text = "Wave: " + wave;
    }

    void SpawnAsteroids()
    {

        DestroyAsteroids();

      //calculate number of asteroids to spawn
        asteroidsLeft = (wave * morePerWave);

        for (int i = 0; i < asteroidsLeft; i++)
        {
            //instantiate an asteroid
            Instantiate(asteroid,
                new Vector3(Random.Range(-9.0f, 9.0f),Random.Range(-6.0f, 6.0f), 0),
                Quaternion.Euler(0, 0, Random.Range(-0.0f, 359.0f)));
        }

        UpdateText();
    }

    public void DecrementLives()
    {
        lives--;
        UpdateText();

        // check if there are lives left
        if (lives < 1)
        {
            // restart game
            BeginGame();
        }
    }

    void DestroyAsteroids()
    {
        GameObject[] asteroidArray1 = GameObject.FindGameObjectsWithTag("Large Asteroid");

        foreach (GameObject current in asteroidArray1)
        {
            GameObject.Destroy(current);
        }

        GameObject[] asteroidArray2 =
            GameObject.FindGameObjectsWithTag("Small Asteroid");

        foreach (GameObject current in asteroidArray2)
        {
            GameObject.Destroy(current);
        }
    }

    public void DecrementAsteroids()
    {
        asteroidsLeft--;
    }


    public void IncrementScore()
    {
        score++;
        UpdateText();

        if (score > highscore)
        {
            highscore = score;
            UpdateText();

            //save new high score
            PlayerPrefs.SetInt("hiscore", highscore);
        }

        //are there any asteroids left?
        if (asteroidsLeft < 1)
        {
            //begin next wave
            wave++;
            SpawnAsteroids();

        }
    }

    public void SplitAsteroid()
    {
        //big asteroid is destroyed
        //3 more are added, collectively +2
        asteroidsLeft += 2;

    }

}