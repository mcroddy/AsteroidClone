﻿using UnityEngine;
using System.Collections;

public class ShipController : MonoBehaviour
{
    float rotationSpeed = 200.0f;
    float thrustForce = 4f;
    public GameObject bullet;

    private GameController gameController;

    void Start()
    {
        // set up gamecontroller
        GameObject gameController = GameObject.FindWithTag("GameController");
        this.gameController = gameController.GetComponent<GameController>();
    }

    void FixedUpdate()
    {
        // check to rotate the ship
        transform.Rotate(0, 0, -Input.GetAxis("Horizontal") *
            rotationSpeed * Time.deltaTime);
        // thrust ship forward
        GetComponent<Rigidbody2D>().
            AddForce(transform.up * thrustForce *
                Input.GetAxis("Vertical"));
        //fire bullet
        if (Input.GetMouseButtonDown(0))ShootBullet();

    }

    void OnTriggerEnter2D(Collider2D c)
    {
        // if it isnt a bullet, it's an asteroid
        if (c.gameObject.tag != "Bullet")
        {
            // upon death, send ship back to center
            transform.position = new Vector3(0, 0, 0);

            // stop the ship velocity
            GetComponent<Rigidbody2D>().velocity = new Vector3(0, 0, 0);
            gameController.DecrementLives();
        }
    }

    void ShootBullet()
    {
        // instantiate a bullet
        Instantiate(bullet,
            new Vector3(transform.position.x, transform.position.y, 0),transform.rotation);
    }
}