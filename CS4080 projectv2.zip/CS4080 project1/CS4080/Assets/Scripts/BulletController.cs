﻿using UnityEngine;
using System.Collections;

public class BulletController : MonoBehaviour
{
    //initialize
    void Start()
    {
        //bullet despawns after 1.5 seconds
        Destroy(gameObject, 1.5f);
        // send bullet forward
        GetComponent<Rigidbody2D>().AddForce(transform.up * 350 );
    }

}